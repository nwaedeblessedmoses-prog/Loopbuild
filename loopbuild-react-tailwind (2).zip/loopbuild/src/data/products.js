// All product details live here. The components read from this array,
// so nothing is repeated in the markup. Add or edit a record to change the page.
import pavingBlocks from '../assets/paving-blocks.jpg'
import schoolDesks from '../assets/school-desks.jpg'
import parkBench from '../assets/park-bench.jpg'
import gardenPlanter from '../assets/garden-planter.jpg'
import roofTiles from '../assets/roof-tiles.jpg'
import collectionBins from '../assets/collection-bins.jpg'

const products = [
  {
    id: 1,
    name: 'Eco Paving Blocks',
    description:
      'Interlocking blocks for walkways, compounds and school yards, made from recycled plastic.',
    price: 'From NGN 9,000 per sq m',
    image: pavingBlocks,
    alt: 'Interlocking paving blocks forming a garden pathway between plants',
  },
  {
    id: 2,
    name: 'School Desk & Bench Set',
    description:
      'A sturdy desk and bench for two pupils, built to handle busy classrooms every day.',
    price: 'NGN 45,000 per set',
    image: schoolDesks,
    alt: 'Wooden school desks with chairs stacked on top in a classroom',
  },
  {
    id: 3,
    name: 'Park Bench',
    description:
      'A weather-resistant bench for parks, estates and bus stops, easy to wipe clean.',
    price: 'NGN 120,000',
    image: parkBench,
    alt: 'Dark slatted park bench beside a stone wall and paved walkway',
  },
  {
    id: 4,
    name: 'Garden Planter',
    description:
      'A durable planter for schools, shops and streets, ready for flowers, herbs or small trees.',
    price: 'NGN 12,000',
    image: gardenPlanter,
    alt: 'Orange plastic plant pots filled with soil in a green tray',
  },
  {
    id: 5,
    name: 'Roof Tile Bundle',
    description:
      'A bundle of lightweight tiles for small buildings, kiosks and sheds.',
    price: 'From NGN 35,000 per bundle',
    image: roofTiles,
    alt: 'Close-up of dark grey roof tiles in neat overlapping rows',
  },
  {
    id: 6,
    name: 'Community Collection Point',
    description:
      'A drop-off station where residents bring clean plastic for LoopBuild to collect and recycle.',
    price: 'From NGN 80,000 setup',
    image: collectionBins,
    alt: 'Four coloured wheelie bins lined up against a grey wall',
  },
]

export default products
