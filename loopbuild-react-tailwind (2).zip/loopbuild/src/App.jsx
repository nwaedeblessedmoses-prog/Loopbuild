import { useState } from 'react'
import Navbar from './components/Navbar.jsx'
import Hero from './components/Hero.jsx'
import About from './components/About.jsx'
import ProductList from './components/ProductList.jsx'
import ContactForm from './components/ContactForm.jsx'
import Footer from './components/Footer.jsx'

export default function App() {
  // The product a visitor chose with "Request a quote". ContactForm uses it
  // to fill in the message. requestId changes on every click, so choosing
  // the same product twice still updates the form.
  const [quoteRequest, setQuoteRequest] = useState(null)

  function handleRequestQuote(product) {
    setQuoteRequest({ productName: product.name, requestId: Date.now() })
  }

  return (
    <>
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[60] focus:rounded-lg focus:bg-amber focus:px-4 focus:py-3 focus:font-bold focus:text-forest"
      >
        Skip to main content
      </a>
      <Navbar />
      <main id="main">
        <Hero />
        <About />
        <ProductList onRequestQuote={handleRequestQuote} />
        <ContactForm quoteRequest={quoteRequest} />
      </main>
      <Footer />
    </>
  )
}
