import heroImage from '../assets/hero-collection.jpg'

const highlights = [
  'Plastic collected from local communities',
  'Durable, low-maintenance products',
  'Quotes for schools, estates and councils',
]

export default function Hero() {
  return (
    <section id="home" className="overflow-hidden bg-cream">
      <div className="container-page grid items-center gap-10 py-12 md:grid-cols-2 md:gap-12 md:py-20 lg:py-24">
        <div>
          <p className="inline-flex items-center gap-2 rounded-full bg-mint px-3 py-1.5 text-sm font-bold">
            <span aria-hidden="true" className="h-2 w-2 rounded-full bg-amber" />
            Recycled plastic products
          </p>

          <h1 className="mt-5 text-balance text-4xl font-extrabold leading-tight tracking-tight sm:text-5xl lg:text-6xl">
            Turning plastic waste into things communities can use
          </h1>

          <p className="mt-5 max-w-xl text-lg leading-relaxed text-forest/80">
            LoopBuild collects plastic waste and turns it into paving blocks, school
            furniture and park benches for schools, estates and councils.
          </p>

          <div className="mt-8 flex flex-wrap gap-3">
            <a href="#products" className="btn-primary w-full sm:w-auto">
              Explore Our Products
            </a>
            <a href="#contact" className="btn-secondary w-full sm:w-auto">
              Request a quote
            </a>
          </div>

          <ul className="mt-8 space-y-2.5">
            {highlights.map((item) => (
              <li key={item} className="flex items-center gap-3 text-sm font-semibold">
                <svg
                  aria-hidden="true"
                  viewBox="0 0 24 24"
                  className="h-5 w-5 shrink-0 text-forest"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <circle cx="12" cy="12" r="10" className="fill-amber stroke-none" />
                  <path d="M7.5 12.5l3 3 6-6.5" />
                </svg>
                {item}
              </li>
            ))}
          </ul>
        </div>

        <div className="relative">
          <div
            aria-hidden="true"
            className="absolute -bottom-3 -right-3 h-full w-full rounded-3xl bg-amber/70"
          />
          <img
            src={heroImage}
            alt="Volunteers in yellow vests collecting plastic bottles from a sandy beach"
            width="800"
            height="534"
            className="relative aspect-[4/3] w-full rounded-3xl object-cover shadow-xl md:aspect-[5/4]"
          />
        </div>
      </div>
    </section>
  )
}
