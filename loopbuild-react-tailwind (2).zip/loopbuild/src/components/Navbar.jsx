import { useEffect, useRef, useState } from 'react'
import Logo from './Logo.jsx'

const links = [
  { label: 'Home', href: '#home' },
  { label: 'About', href: '#about' },
  { label: 'Products', href: '#products' },
  { label: 'Contact', href: '#contact' },
]

export default function Navbar() {
  // true when the phone menu is open, false when it is closed
  const [isOpen, setIsOpen] = useState(false)
  const buttonRef = useRef(null)

  // Pressing Escape closes the menu and returns focus to the menu button.
  useEffect(() => {
    if (!isOpen) return undefined

    function handleKeyDown(event) {
      if (event.key === 'Escape') {
        setIsOpen(false)
        buttonRef.current?.focus()
      }
    }

    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [isOpen])

  return (
    <header className="sticky top-0 z-50 bg-forest text-cream shadow-md">
      <nav aria-label="Main" className="container-page">
        <div className="flex h-16 items-center justify-between">
          <a href="#home" aria-label="LoopBuild, back to the top" className="rounded-lg">
            <Logo />
          </a>

          {/* Menu button: only visible on phones */}
          <button
            ref={buttonRef}
            type="button"
            aria-expanded={isOpen}
            aria-controls="mobile-menu"
            aria-label="Main menu"
            onClick={() => setIsOpen(!isOpen)}
            className="inline-flex h-11 w-11 items-center justify-center rounded-lg transition-colors hover:bg-white/10 md:hidden"
          >
            <svg
              aria-hidden="true"
              viewBox="0 0 24 24"
              className="h-6 w-6"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.25"
              strokeLinecap="round"
            >
              {isOpen ? (
                <path d="M6 6l12 12M18 6L6 18" />
              ) : (
                <path d="M4 7h16M4 12h16M4 17h16" />
              )}
            </svg>
          </button>

          {/* Links: visible from tablet width upwards */}
          <ul className="hidden items-center gap-1 md:flex">
            {links.map((link) => (
              <li key={link.href}>
                <a
                  href={link.href}
                  className="rounded-lg px-3 py-2 text-sm font-semibold transition-colors hover:bg-white/10"
                >
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
        </div>

        {/* Phone menu: shown or hidden by the isOpen state */}
        <ul
          id="mobile-menu"
          className={`${isOpen ? 'block' : 'hidden'} border-t border-white/15 pb-4 pt-2 md:hidden`}
        >
          {links.map((link) => (
            <li key={link.href}>
              <a
                href={link.href}
                onClick={() => setIsOpen(false)}
                className="block rounded-lg px-3 py-3 text-base font-semibold transition-colors hover:bg-white/10"
              >
                {link.label}
              </a>
            </li>
          ))}
        </ul>
      </nav>
    </header>
  )
}
