import { useState } from 'react'
import ProductCard from './ProductCard.jsx'
import products from '../data/products.js'

export default function ProductList({ onRequestQuote }) {
  // The text typed into the search box
  const [query, setQuery] = useState('')

  // Ignore capital letters and extra spaces, then keep products whose name matches.
  // The original products array is never changed.
  const searchText = query.trim().toLowerCase()
  const filteredProducts = products.filter((product) =>
    product.name.toLowerCase().includes(searchText),
  )

  return (
    <section id="products" className="bg-cream">
      <div className="container-page py-16 md:py-24">
        <div className="flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
          <div className="max-w-2xl">
            <p className="eyebrow">What we make</p>
            <h2 className="mt-3 text-3xl font-extrabold tracking-tight sm:text-4xl">
              Our products
            </h2>
            <p className="mt-4 text-lg leading-relaxed text-forest/80">
              Durable products made from recycled plastic waste. Prices are starting
              prices. Contact us for a full quote.
            </p>
          </div>

          <div className="w-full md:max-w-sm">
            <label htmlFor="product-search" className="block text-sm font-bold">
              Search products
            </label>
            <div className="relative mt-2">
              <svg
                aria-hidden="true"
                viewBox="0 0 24 24"
                className="pointer-events-none absolute left-3.5 top-1/2 h-5 w-5 -translate-y-1/2 text-forest/70"
                fill="none"
                stroke="currentColor"
                strokeWidth="2.25"
                strokeLinecap="round"
              >
                <circle cx="11" cy="11" r="7" />
                <path d="M20 20l-3.5-3.5" />
              </svg>
              <input
                id="product-search"
                type="search"
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Try bench or block"
                autoComplete="off"
                className="h-12 w-full rounded-xl border-2 border-forest/30 bg-white pl-11 pr-11 text-base placeholder:text-forest/60 focus:border-forest [&::-webkit-search-cancel-button]:hidden"
              />
              {query && (
                <button
                  type="button"
                  aria-label="Clear search"
                  onClick={() => setQuery('')}
                  className="absolute right-1.5 top-1/2 flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-lg text-forest transition-colors hover:bg-mint"
                >
                  <svg
                    aria-hidden="true"
                    viewBox="0 0 24 24"
                    className="h-5 w-5"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.25"
                    strokeLinecap="round"
                  >
                    <path d="M6 6l12 12M18 6L6 18" />
                  </svg>
                </button>
              )}
            </div>
          </div>
        </div>

        <p role="status" className="mt-8 text-sm font-semibold text-forest/80">
          Showing {filteredProducts.length} of {products.length} products
        </p>

        {filteredProducts.length > 0 ? (
          <ul className="mt-4 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onRequestQuote={onRequestQuote}
              />
            ))}
          </ul>
        ) : (
          <div className="mt-4 rounded-3xl border-2 border-dashed border-forest/30 bg-white px-6 py-12 text-center">
            <h3 className="text-xl font-extrabold">No products found</h3>
            <p className="mx-auto mt-2 max-w-md text-forest/80">
              We could not find a product named &ldquo;{query.trim()}&rdquo;. Check the
              spelling or try a shorter word.
            </p>
            <button type="button" onClick={() => setQuery('')} className="btn-secondary mt-6">
              Clear search
            </button>
          </div>
        )}
      </div>
    </section>
  )
}
