import Logo from './Logo.jsx'

const links = [
  { label: 'Home', href: '#home' },
  { label: 'About', href: '#about' },
  { label: 'Products', href: '#products' },
  { label: 'Contact', href: '#contact' },
]

export default function Footer() {
  return (
    <footer className="bg-forest text-cream">
      <div className="container-page py-10">
        <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
          <div>
            <Logo />
            <p className="mt-3 max-w-sm text-balance text-sm leading-relaxed text-cream/85">
              Turning plastic waste into things communities can use.
            </p>
          </div>

          <nav aria-label="Footer">
            <ul className="flex flex-wrap gap-x-6 gap-y-2">
              {links.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    className="rounded text-sm font-semibold underline-offset-4 hover:underline"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>
        </div>

        <p className="mt-8 border-t border-white/15 pt-6 text-sm text-cream/85">
          &copy; {new Date().getFullYear()} LoopBuild. All rights reserved. Designed for durability,
          built from waste, made to serve communities.
        </p>
      </div>
    </footer>
  )
}
