import aboutImage from '../assets/about-paving.jpg'

const steps = [
  {
    title: 'Collect',
    text: 'Households, schools and markets drop off clean plastic at community collection points.',
  },
  {
    title: 'Recycle',
    text: 'We sort, shred and melt the plastic into material that is ready to be moulded.',
  },
  {
    title: 'Build',
    text: 'The material becomes paving blocks, furniture, benches, planters and roof tiles.',
  },
]

export default function About() {
  return (
    <section id="about" className="bg-white">
      <div className="container-page py-16 md:py-24">
        <div className="grid items-center gap-10 md:grid-cols-2 md:gap-14">
          <img
            src={aboutImage}
            alt="Worker in yellow gloves laying interlocking paving blocks on a walkway"
            width="800"
            height="533"
            loading="lazy"
            className="aspect-[4/3] w-full rounded-3xl object-cover shadow-lg"
          />

          <div>
            <p className="eyebrow">Who we are</p>
            <h2 className="mt-3 text-3xl font-extrabold tracking-tight sm:text-4xl">
              About LoopBuild
            </h2>
            <p className="mt-5 text-lg leading-relaxed text-forest/80">
              LoopBuild is a small recycling business that turns collected plastic waste into
              durable products for the community. We serve school administrators, estate
              managers, local councils and community groups that need affordable paving,
              seating and furniture.
            </p>
            <p className="mt-4 text-lg leading-relaxed text-forest/80">
              Every order keeps plastic out of drains and dumpsites and gives it a second
              life where people use it every day.
            </p>
          </div>
        </div>

        <div className="mt-14 md:mt-20">
          <h3 className="text-xl font-extrabold">How it works</h3>
          <ol className="mt-6 grid gap-4 md:grid-cols-3 md:gap-6">
            {steps.map((step, index) => (
              <li key={step.title} className="rounded-2xl bg-cream p-6 ring-1 ring-forest/10">
                <span
                  aria-hidden="true"
                  className="flex h-10 w-10 items-center justify-center rounded-full bg-forest text-base font-extrabold text-cream"
                >
                  {index + 1}
                </span>
                <h4 className="mt-4 text-lg font-bold">{step.title}</h4>
                <p className="mt-2 text-base leading-relaxed text-forest/80">{step.text}</p>
              </li>
            ))}
          </ol>
        </div>
      </div>
    </section>
  )
}
