// One product card. The product arrives through props.
export default function ProductCard({ product, onRequestQuote }) {
  const { name, description, price, image, alt } = product

  return (
    <li className="flex">
      <article className="group flex w-full flex-col overflow-hidden rounded-2xl bg-white shadow-sm ring-1 ring-forest/10 transition duration-300 hover:shadow-xl motion-safe:hover:-translate-y-1">
        <div className="overflow-hidden">
          <img
            src={image}
            alt={alt}
            width="800"
            height="600"
            loading="lazy"
            decoding="async"
            className="aspect-[4/3] w-full object-cover transition duration-500 motion-safe:group-hover:scale-105"
          />
        </div>

        <div className="flex flex-1 flex-col p-5">
          <h3 className="text-lg font-bold leading-snug">{name}</h3>
          <p className="mt-2 flex-1 text-sm leading-relaxed text-forest/80">{description}</p>
          <p className="mt-4 text-base font-extrabold">{price}</p>

          {/* The link scrolls to the contact form. The click handler fills in the message. */}
          <a
            href="#contact"
            onClick={() => onRequestQuote(product)}
            className="mt-4 inline-flex min-h-11 items-center justify-center rounded-xl bg-forest px-4 py-2.5 text-sm font-bold text-cream transition-colors duration-200 hover:bg-forest-dark"
          >
            Request a quote
            <span className="sr-only"> for {name}</span>
          </a>
        </div>
      </article>
    </li>
  )
}
