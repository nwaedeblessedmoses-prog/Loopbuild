import { useEffect, useRef, useState } from 'react'

const emptyForm = { name: '', email: '', message: '' }
const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
const contactEmail = 'nwaedeblessedmoses@gmail.com'

// Builds a mailto: link, so a valid enquiry opens in the visitor's email app
// with the message ready to send to the business.
function buildMailto(values) {
  const name = values.name.trim()
  const subject = `LoopBuild enquiry from ${name}`
  const body = `${values.message.trim()}\n\nName: ${name}\nEmail: ${values.email.trim()}`
  return `mailto:${contactEmail}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`
}

// Returns an object with one error message for each invalid field.
function validate(values) {
  const errors = {}

  if (!values.name.trim()) {
    errors.name = 'Enter your name.'
  }

  if (!values.email.trim()) {
    errors.email = 'Enter your email address.'
  } else if (!emailPattern.test(values.email.trim())) {
    errors.email = 'Enter a valid email address, such as name@example.com.'
  }

  if (!values.message.trim()) {
    errors.message = 'Enter a message.'
  }

  return errors
}

const contactDetails = [
  {
    label: 'Email',
    value: contactEmail,
    href: `mailto:${contactEmail}`,
    icon: <path d="M4 6h16v12H4zM4 7l8 6 8-6" />,
  },
  {
    label: 'Phone',
    value: '+234 814 302 5227',
    href: 'tel:+2348143025227',
    icon: (
      <path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z" />
    ),
  },
  {
    label: 'Opening hours',
    value: 'Monday to Friday, 9am to 5pm',
    icon: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M12 7v5l3 2" />
      </>
    ),
  },
]

// A label, a form control and an optional error message.
function Field({ id, label, error, children }) {
  return (
    <div>
      <label htmlFor={id} className="block text-sm font-bold">
        {label}
      </label>
      <div className="mt-2">{children}</div>
      {error && (
        <p id={`${id}-error`} className="mt-1.5 text-sm font-semibold text-red-700">
          {error}
        </p>
      )}
    </div>
  )
}

const controlClass =
  'w-full rounded-xl border-2 bg-white px-4 py-3 text-base placeholder:text-forest/60 focus:border-forest'

export default function ContactForm({ quoteRequest }) {
  const [form, setForm] = useState(emptyForm)
  const [errors, setErrors] = useState({})
  const [status, setStatus] = useState('idle') // 'idle' | 'error' | 'success'

  const nameRef = useRef(null)
  const emailRef = useRef(null)
  const messageRef = useRef(null)
  const fieldRefs = { name: nameRef, email: emailRef, message: messageRef }

  // When a product card's "Request a quote" link is used, fill in the message.
  useEffect(() => {
    if (!quoteRequest) return
    setForm((current) => ({
      ...current,
      message: `Hello, I would like a quote for ${quoteRequest.productName}.`,
    }))
    setErrors({})
    setStatus('idle')
  }, [quoteRequest])

  function handleChange(event) {
    const { name, value } = event.target
    setForm({ ...form, [name]: value })
    // Remove the error for this field as soon as the visitor edits it
    if (errors[name]) {
      setErrors({ ...errors, [name]: undefined })
    }
    if (status === 'success') {
      setStatus('idle')
    }
  }

  function handleSubmit(event) {
    event.preventDefault() // stop the page from reloading

    const nextErrors = validate(form)
    setErrors(nextErrors)

    const firstInvalid = ['name', 'email', 'message'].find((field) => nextErrors[field])
    if (firstInvalid) {
      setStatus('error')
      fieldRefs[firstInvalid].current?.focus()
      return
    }

    // Valid: open the visitor's email app with the enquiry ready to send, then show the confirmation.
    window.location.href = buildMailto(form)
    setStatus('success')
    setForm(emptyForm)
  }

  function borderFor(field) {
    return errors[field] ? 'border-red-700' : 'border-forest/30'
  }

  return (
    <section id="contact" className="bg-white">
      <div className="container-page grid gap-12 py-16 md:py-24 lg:grid-cols-5 lg:gap-14">
        <div className="min-w-0 lg:col-span-2">
          <p className="eyebrow">Get in touch</p>
          <h2 className="mt-3 text-3xl font-extrabold tracking-tight sm:text-4xl">
            Contact us
          </h2>
          <p className="mt-4 text-lg leading-relaxed text-forest/80">
            Tell us what you need and which product you are interested in. Email or call us
            and we will prepare a quote.
          </p>

          <ul className="mt-8 space-y-5">
            {contactDetails.map((item) => (
              <li key={item.label} className="flex items-start gap-4">
                <span
                  aria-hidden="true"
                  className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-mint"
                >
                  <svg
                    viewBox="0 0 24 24"
                    className="h-5 w-5"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    {item.icon}
                  </svg>
                </span>
                <div className="min-w-0">
                  <p className="text-sm font-bold text-forest/75">{item.label}</p>
                  {item.href ? (
                    <a
                      href={item.href}
                      className="font-semibold underline-offset-4 [overflow-wrap:anywhere] hover:underline"
                    >
                      {item.value}
                    </a>
                  ) : (
                    <p className="font-semibold [overflow-wrap:anywhere]">{item.value}</p>
                  )}
                </div>
              </li>
            ))}
          </ul>
        </div>

        <form
          onSubmit={handleSubmit}
          noValidate
          className="rounded-3xl bg-cream p-6 ring-1 ring-forest/10 sm:p-8 lg:col-span-3"
        >
          <div className="space-y-5">
            <Field id="name" label="Name" error={errors.name}>
              <input
                ref={nameRef}
                id="name"
                name="name"
                type="text"
                autoComplete="name"
                value={form.name}
                onChange={handleChange}
                aria-invalid={errors.name ? 'true' : undefined}
                aria-describedby={errors.name ? 'name-error' : undefined}
                className={`${controlClass} ${borderFor('name')}`}
              />
            </Field>

            <Field id="email" label="Email" error={errors.email}>
              <input
                ref={emailRef}
                id="email"
                name="email"
                type="email"
                autoComplete="email"
                value={form.email}
                onChange={handleChange}
                aria-invalid={errors.email ? 'true' : undefined}
                aria-describedby={errors.email ? 'email-error' : undefined}
                className={`${controlClass} ${borderFor('email')}`}
              />
            </Field>

            <Field id="message" label="Message" error={errors.message}>
              <textarea
                ref={messageRef}
                id="message"
                name="message"
                rows={5}
                value={form.message}
                onChange={handleChange}
                aria-invalid={errors.message ? 'true' : undefined}
                aria-describedby={errors.message ? 'message-error' : undefined}
                className={`${controlClass} ${borderFor('message')}`}
              />
            </Field>
          </div>

          {status === 'error' && (
            <p
              role="alert"
              className="mt-6 rounded-xl bg-red-100 px-4 py-3 text-sm font-bold text-red-900"
            >
              Please fix the highlighted fields and try again.
            </p>
          )}

          {status === 'success' && (
            <p
              role="status"
              className="mt-6 rounded-xl bg-green-100 px-4 py-3 text-sm font-bold text-green-900"
            >
              Almost done. Your email app should open with your enquiry ready to send. If it
              does not, email us at {contactEmail}.
            </p>
          )}

          <button type="submit" className="btn-primary mt-6 w-full sm:w-auto">
            Send enquiry
          </button>
        </form>
      </div>
    </section>
  )
}
