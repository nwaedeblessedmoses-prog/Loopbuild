// Text-based logo with a small loop mark.
export default function Logo({ className = '' }) {
  return (
    <span
      className={`inline-flex items-center gap-2 text-xl font-extrabold tracking-tight ${className}`}
    >
      <svg
        aria-hidden="true"
        viewBox="0 0 32 32"
        className="h-8 w-8 shrink-0"
        fill="none"
      >
        <rect width="32" height="32" rx="8" fill="#F2A541" />
        <path
          d="M24 16a8 8 0 1 1-2.34-5.66"
          stroke="#14452F"
          strokeWidth="3"
          strokeLinecap="round"
        />
        <path
          d="M24 7v5h-5"
          stroke="#14452F"
          strokeWidth="3"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
      <span>LoopBuild</span>
    </span>
  )
}
