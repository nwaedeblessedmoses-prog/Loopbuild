# LoopBuild

LoopBuild is a one-page responsive website for a concept brand that turns collected plastic waste into paving blocks, school furniture, park benches and other community products. It was built for the Techup Academy "Build a Brand Website" project. The prices and opening hours on the site are sample content. The email address and phone number in the Contact section are the developer's own contact details.

- **Live site:** _add your Vercel or Render link here_
- **Repository:** _add your GitHub link here_

## Features

- Six sections on one page: Navbar, Home, About, Products, Contact and Footer.
- **Mobile menu** controlled by a boolean state (`isOpen`). The menu button sets `aria-expanded`, and the Escape key closes the menu.
- **Product search** that filters by product name, ignores capital letters and extra spaces, and shows a "No products found" message with a Clear search button when nothing matches.
- **Request a quote** button on each product card. It scrolls to the contact form and fills in the message.
- **Enquiry form** with validation for name, email format and message. Errors appear under each field and focus moves to the first invalid field. When the form is valid, the visitor's email app opens with the enquiry ready to send to the business email address, and a confirmation message appears. The site has no server, so nothing is stored.
- Responsive layout checked from 320px phones up to wide desktops, with no sideways scrolling.
- Accessibility: skip link, landmarks, one `h1`, labelled form fields, alt text on every image, visible keyboard focus and `prefers-reduced-motion` support.

## Tech

- React 19
- Vite 7
- Tailwind CSS v4 (`@tailwindcss/vite` plugin, theme colours defined in `src/index.css`)

## Run it locally

You need Node.js 20.19 or newer (Node 22 also works). Check with `node -v`.

```bash
npm install
npm run dev
```

Open the address that Vite prints (usually http://localhost:5173).

To check the production build:

```bash
npm run build
npm run preview
```

## Project structure

```
loopbuild/
  index.html
  package.json
  vite.config.js
  public/
    favicon.svg
  src/
    main.jsx
    App.jsx
    index.css            Tailwind import, theme colours, small shared utilities
    data/
      products.js        The six products (name, description, price, image, alt text)
    assets/              Optimised photos
    components/
      Navbar.jsx         Mobile menu state
      Hero.jsx
      About.jsx
      ProductList.jsx    Search state and empty state
      ProductCard.jsx
      ContactForm.jsx    Form state, validation, success message
      Footer.jsx
      Logo.jsx
```

## How the main features work

**Mobile menu.** `Navbar.jsx` keeps one piece of state, `isOpen`. The button flips it, and the same value is written to `aria-expanded` and decides whether the menu list is shown. Choosing a link or pressing Escape sets it back to `false`.

**Search.** `ProductList.jsx` keeps the typed text in `query`. On every render it lowercases and trims the text, then runs `products.filter(...)` on the product names. The original array is never changed. If the result is empty, an empty state is shown instead of the grid.

**Form.** `ContactForm.jsx` keeps `form`, `errors` and `status` in state. On submit it calls `preventDefault()`, runs a `validate()` function and either shows the errors or, when the form is valid, opens the visitor's email app with a `mailto:` link and shows the confirmation message.

## Deploy

### Vercel

1. Push the project to GitHub.
2. On vercel.com choose **Add New, Project** and import the repository.
3. Vercel detects Vite. Check that the build command is `npm run build` and the output directory is `dist`.
4. Select **Deploy** and copy the live link into this README.

### Render

1. Push the project to GitHub.
2. On render.com choose **New, Static Site** and connect the repository.
3. Build command: `npm install && npm run build`. Publish directory: `dist`.
4. Select **Create Static Site** and copy the live link into this README.

## Image credits

Fill in the photographer names and licence links before you submit. Open each photo's page on Pexels or Unsplash and copy the credit shown there.

| File in `src/assets` | Used for | Original file | Source and licence |
| --- | --- | --- | --- |
| `hero-collection.jpg` | Home section | `premium_photo-1663039947303-0fad26f737b8.jpeg` | Unsplash+ (see the warning below). Photographer: _add_ |
| `about-paving.jpg` | About section | `premium_photo-1661721997649-c7030cfa240a.jpeg` | Unsplash+ (see the warning below). Photographer: _add_ |
| `paving-blocks.jpg` | Eco Paving Blocks | `photo-1676984290997-b862e8f0919c.jpeg` | Unsplash. Photographer: _add_ |
| `school-desks.jpg` | School Desk and Bench Set | `pexels-pixabay-256491.jpg` | Pexels. Photographer: Pixabay |
| `park-bench.jpg` | Park Bench | `pexels-theshuttervision-33815696.jpg` | Pexels. Photographer: theshuttervision |
| `garden-planter.jpg` | Garden Planter | `pexels-christina99999-37382517.jpg` | Pexels. Photographer: christina99999 |
| `roof-tiles.jpg` | Roof Tile Bundle | `photo-1518736346281-76873166a64a.jpeg` | Unsplash. Photographer: _add_ |
| `collection-bins.jpg` | Community Collection Point | _add the original file name_ | _add the source, photographer and licence_ |

**Licence warning.** Files named `premium_photo-...` come from **Unsplash+**, which is a paid collection with its own licence. If you downloaded them with a free account or a trial, check that your licence allows public use before you publish. If you are unsure, replace the Home and About images with free Unsplash or Pexels photos and update this table.

## What I tested

- Menu opens and closes, `aria-expanded` changes, Escape closes it.
- Search: `bench`, `BENCH` and `BlOcK` all match; extra spaces are ignored; `pizza` shows the empty state; Clear search restores all six products.
- Form: empty submit shows three errors and focuses the name field; a bad email shows the format message; a valid submit opens the email app with the enquiry ready to send, shows the confirmation message and does not reload the page.
- Layout at 320, 375, 768, 1024 and 1440 px wide with no sideways scrolling.
- Tab through the whole page and check that the focus ring is always visible.

## A challenge I solved

_Write two or three sentences here in your own words. For example: what was hard (the sticky navbar covering section titles, keeping the search state in the right component, or validating the form), what you tried, and what fixed it._

## Demo script (3 minutes)

1. **0:00** Show the live link and scroll through Home, About, Products, Contact and Footer.
2. **0:40** Resize the window to phone width. Open the menu, point out `aria-expanded` in the browser tools, choose a link.
3. **1:20** Search `bench`, then `BENCH`, then `pizza` to show the empty state, then Clear search.
4. **2:00** Press Request a quote on a product and show the message filling in.
5. **2:20** Submit the empty form to show errors, enter a bad email, then complete it and show the success message.
6. **2:50** Show the repository and say what you would improve next.

---

LoopBuild is a concept brand, designed and built at Techup Academy.
